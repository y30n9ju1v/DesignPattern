// 6_Bridge1 - 90 page
#include <iostream>
using namespace std;

class IPod 
{
public:
	void Play() { cout << "Play MP3 with IPod" << endl; }
	void Stop() { cout << "Stop" << endl; }
};

class People
{
public:
	void Use(IPod* p)
	{
		p->Play();
		p->Stop();
	}
};
int main()
{
	People p;
	IPod pod;
	p.Use(&pod);
}


