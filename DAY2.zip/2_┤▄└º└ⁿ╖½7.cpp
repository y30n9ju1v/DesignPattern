#include <iostream>
#include <vector>

int main()
{
	std::vector<int> v;
}